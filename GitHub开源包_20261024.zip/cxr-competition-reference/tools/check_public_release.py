"""Conservative local checks for this source-only public release.

This is a review aid, not a proof that publication rights or privacy are settled.
It prints categories and relative file names, never matched content.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = "PUBLIC_MANIFEST.json"
ALLOWED_SUFFIXES = {".py", ".md", ".json", ".txt", ".toml", ".yml", ".yaml"}
ALLOWED_NAMES = {"LICENSE", "NOTICE", ".gitignore", ".gitattributes"}
PATTERNS = {
    "private_key": re.compile(r"-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----"),
    "personal_windows_path": re.compile(r"\b[A-Za-z]:[\\/]Users[\\/][^\s\"']+", re.I),
    "private_network": re.compile(
        r"\b(?:10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|"
        r"172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2})\b"),
    "common_access_token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16})\b"),
}


def files(root: Path):
    return sorted(
        (p for p in root.rglob("*") if p.is_file() and ".git" not in p.relative_to(root).parts),
        key=lambda p: p.relative_to(root).as_posix(),
    )


def inventory(root: Path):
    return [{"path": p.relative_to(root).as_posix(), "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in files(root) if p.relative_to(root).as_posix() != MANIFEST]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--write-manifest", action="store_true",
                        help="Refresh the inventory after reviewing intended changes.")
    args = parser.parse_args()
    root = args.root.resolve()
    errors = []
    for p in files(root):
        rel = p.relative_to(root).as_posix()
        if p.is_symlink():
            errors.append((rel, "symlink"))
        if p.suffix.lower() not in ALLOWED_SUFFIXES and p.name not in ALLOWED_NAMES:
            errors.append((rel, "unexpected_file_type"))
            continue
        if p.stat().st_size > 2_000_000:
            errors.append((rel, "unexpected_large_file"))
            continue
        try:
            content = p.read_text(encoding="utf-8-sig")
        except UnicodeError:
            errors.append((rel, "non_utf8_content"))
            continue
        for category, pattern in PATTERNS.items():
            if pattern.search(content):
                errors.append((rel, category))
    current = inventory(root)
    manifest_path = root / MANIFEST
    if not errors and args.write_manifest:
        manifest_path.write_text(json.dumps({"schema_version": 1, "files": current},
                                           indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if manifest_path.exists() and not args.write_manifest:
        try:
            recorded = json.loads(manifest_path.read_text(encoding="utf-8"))["files"]
            if recorded != current:
                errors.append((MANIFEST, "inventory_mismatch"))
        except (ValueError, KeyError):
            errors.append((MANIFEST, "invalid_manifest"))
    if errors:
        for path, category in errors:
            print(f"FAIL {category}: {path}")
        raise SystemExit(1)
    print(f"PASS: {len(current)} source/document files checked; no listed sensitive pattern found.")
    print("No data or weights are included. Human review of rights and identifiers remains necessary.")


if __name__ == "__main__":
    main()
