# 第三方依赖与来源

本目录的 `cxr_reference/` 是为公开整理而编写的便携参考实现，借鉴本项目原有训练、患者划分、EMA、概率聚合和统计分析方法。它不是历史部署包的逐字副本，也不包含第三方骨干网络实现、数据、预训练权重或最终权重。

代码通过普通 Python 导入调用以下依赖，其许可证不因本项目的许可证而改变。安装或再分发依赖时，请保留对应版本的完整许可证与 notices。

| 依赖 | 上游代码与许可证 | 本项目使用方式 |
|---|---|---|
| PyTorch | https://github.com/pytorch/pytorch/blob/main/LICENSE （BSD 风格及其第三方 notices） | 张量、自动微分、优化器、AMP、数据加载 |
| torchvision | https://github.com/pytorch/vision/blob/main/LICENSE （BSD 3-Clause） | 导入公开架构与图像变换；未复制网络实现 |
| NumPy | https://github.com/numpy/numpy/blob/main/LICENSE.txt （BSD 3-Clause，含附加 notices） | 数组与固定随机数生成器 |
| pandas | https://github.com/pandas-dev/pandas/blob/main/LICENSE （BSD 3-Clause） | 元数据、CSV 与标识对齐 |
| scikit-learn | https://github.com/scikit-learn/scikit-learn/blob/main/COPYING （BSD 3-Clause） | ROC AUC 计算 |
| Pillow | https://github.com/python-pillow/Pillow/blob/main/LICENSE （HPND/Pillow 许可证，含组件 notices） | 图像解码、EXIF、缩放和填充 |

链接指向当前上游文件，实际安装版本的许可证是最终依据。`requirements.txt` 是兼容范围，不是复现历史运行环境的锁文件。

预训练权重许可证与软件许可证不是同一个核验问题。参考实现默认随机初始化，绝不自动下载权重；如果用户显式提供初始化，仍须自行核验来源、上游训练数据、许可证、再分发权及适用赛事规则。代码不根据文件名或 SHA 自动宣称某份权重合规。

历史项目使用过的上游模型及许可证核验材料见仓库研究归档文档。该列表不授权把比赛数据、私有日志或历史模型权重一并公开。
