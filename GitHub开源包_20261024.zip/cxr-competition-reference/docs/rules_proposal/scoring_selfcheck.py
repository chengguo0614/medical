"""Synthetic-only boundary checks for the participant-proposed scorer.

Writes temporary invented CSV files; never reads competition data or images.
Run with: python scoring_selfcheck.py
"""
import copy
import csv
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

from scoring_reference import SCORE_CLASSES, SUBMISSION_COLUMNS, TRUTH_COLUMNS, rank_key, score


class ProposedScorerChecks(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="proposed_scorer_synthetic_")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.truth, self.prediction = [], []
        for index in range(4):
            for class_id in range(1, 11):
                key = [f"subject_{index // 2:04d}", f"study_{index:05d}", str(class_id)]
                target = index % 2
                self.truth.append(key + [str(target)])
                self.prediction.append(key + ["0.8" if target else "0.2", "0.5"])

    def write(self, name, columns, rows):
        path = self.root / name
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(columns)
            writer.writerows(rows)
        return path

    def files(self, truth=None, prediction=None, columns=None):
        return (self.write("truth.csv", TRUTH_COLUMNS, self.truth if truth is None else truth),
                self.write("submission.csv", SUBMISSION_COLUMNS if columns is None else columns,
                           self.prediction if prediction is None else prediction))

    def test_perfect_and_leading_zero_ids(self):
        def numeric_ids(rows):
            return [[f"{int(r[0].split('_')[-1]) + 1:06d}",
                     f"{int(r[1].split('_')[-1]) + 1:07d}"] + r[2:] for r in rows]
        truth, pred = numeric_ids(self.truth), numeric_ids(self.prediction)
        report = score(*self.files(truth, pred))
        self.assertEqual(report["macro_auc"], 1.0)
        self.assertEqual(report["macro_f1"], 1.0)
        self.assertEqual(report["rank_keys"], ["1.000000000000", "1.000000000000"])
        self.assertEqual((report["studies"], report["patients"]), (4, 2))
        pred[0][1] = pred[0][1].lstrip("0")
        with self.assertRaises(ValueError):
            score(*self.files(truth, pred))

    def test_tied_auc_and_gate_equality(self):
        pred = [r[:3] + ["0.5", "0.5"] for r in self.prediction]
        report = score(*self.files(prediction=pred))
        self.assertEqual(report["macro_auc"], 0.5)
        self.assertAlmostEqual(report["macro_f1"], 2 / 3)
        self.assertEqual(report["per_class"]["1"]["TP"], 2)

    def test_all_below_gate_keeps_complete_grid(self):
        pred = [r[:3] + ["0.4", "0.5"] for r in self.prediction]
        self.assertEqual(score(*self.files(prediction=pred))["macro_f1"], 0.0)

    def test_class_ten_excluded_but_required(self):
        base = score(*self.files())
        truth, pred = copy.deepcopy(self.truth), copy.deepcopy(self.prediction)
        for row in truth:
            if row[2] == "10":
                row[3] = "0"  # Undefined c10 AUC must not block nine-class score.
        for row in pred:
            if row[2] == "10":
                row[3] = "1"
        changed = score(*self.files(truth, pred))
        for field in ("macro_auc", "macro_f1", "rank_keys", "per_class_auc", "per_class_f1"):
            self.assertEqual(changed[field], base[field])
        self.assertEqual(set(changed["per_class_auc"]), set(SCORE_CLASSES))
        with self.assertRaises(ValueError):
            score(*self.files(prediction=[r for r in pred if r[2] != "10"]))

    def test_row_order_does_not_change_metrics(self):
        base = score(*self.files())
        truth, pred = copy.deepcopy(self.truth), copy.deepcopy(self.prediction)
        random.Random(123).shuffle(truth)
        random.Random(456).shuffle(pred)
        changed = score(*self.files(truth, pred))
        for field in ("macro_auc", "macro_f1", "rank_keys", "per_class"):
            self.assertEqual(changed[field], base[field])

    def test_duplicate_missing_extra_keys_and_subject_conflict(self):
        extra = [["extra_subject", "extra_study", str(c), "0.4", "0.5"] for c in range(1, 11)]
        conflict = copy.deepcopy(self.prediction)
        conflict[0][0] = "another_subject"
        cases = [self.prediction + self.prediction[:1], self.prediction[1:],
                 self.prediction + extra, conflict]
        for rows in cases:
            with self.subTest(rows=len(rows)), self.assertRaises(ValueError):
                score(*self.files(prediction=rows))

    def test_exact_column_order_and_gate_required(self):
        for columns in [SUBMISSION_COLUMNS[:-1], list(reversed(SUBMISSION_COLUMNS)),
                        SUBMISSION_COLUMNS + ["Extra"]]:
            with self.subTest(columns=columns), self.assertRaises(ValueError):
                score(*self.files(columns=columns))

    def test_malformed_rows_empty_ids_and_invalid_class(self):
        for field, value in [(0, ""), (1, "   "), (1, "study_00000 "), (1, "bad\nid"),
                             (2, "01"), (2, "0"), (2, "11"), (2, "c1")]:
            pred = copy.deepcopy(self.prediction)
            pred[0][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                score(*self.files(prediction=pred))
        with self.assertRaises(ValueError):
            score(*self.files(prediction=[self.prediction[0][:-1]] + self.prediction[1:]))

    def test_finite_unit_interval_probability_and_gate(self):
        for field in (3, 4):
            for value in ("NaN", "inf", "-inf", "1e9999", "-0.01", "1.00000000000000000001", "", "0.5 "):
                pred = copy.deepcopy(self.prediction)
                pred[0][field] = value
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    score(*self.files(prediction=pred))

    def test_gate_fixed_per_class_including_class_ten(self):
        for class_id in ("1", "10"):
            pred = copy.deepcopy(self.prediction)
            next(r for r in pred if r[2] == class_id)[4] = "0.4"
            with self.subTest(class_id=class_id), self.assertRaises(ValueError):
                score(*self.files(prediction=pred))
        pred = copy.deepcopy(self.prediction)
        pred[0][4] = ".50"  # Same exact numeric threshold is allowed.
        self.assertEqual(score(*self.files(prediction=pred))["macro_auc"], 1.0)

    def test_unknown_truth_and_undefined_scored_auc_rejected(self):
        for value in ("", "-1", "NaN", "unknown", "0.0"):
            truth = copy.deepcopy(self.truth)
            truth[0][3] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                score(*self.files(truth=truth))
        truth = [r[:3] + (["0"] if r[2] == "1" else r[3:]) for r in self.truth]
        with self.assertRaisesRegex(ValueError, "undefined"):
            score(*self.files(truth=truth))

    def test_half_up_rank_rounding(self):
        self.assertEqual(rank_key(0.1234567890125), "0.123456789013")
        self.assertEqual(rank_key(0.1234567890124), "0.123456789012")

    def test_cli_json_and_optimized_rejection(self):
        truth, pred = self.files()
        script = Path(__file__).with_name("scoring_reference.py")
        output = self.root / "report.json"
        command = [sys.executable, str(script), "--truth", str(truth), "--submission", str(pred)]
        result = subprocess.run(command + ["--output", str(output)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(output.read_text(encoding="utf-8"))["macro_auc"], 1.0)
        repeated = subprocess.run(command + ["--output", str(output)], capture_output=True, text=True)
        self.assertEqual(repeated.returncode, 2)
        self.files(prediction=self.prediction + self.prediction[:1])
        invalid = subprocess.run([sys.executable, "-O"] + command[1:], capture_output=True, text=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertIn("duplicate", invalid.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
