"""Participant-proposed scorer, NOT the organizer's verified scoring backend.

Python 3.10+ standard library only. Complete ten-class long-form files are
required; classes 1..9 are scored under this proposal, while class 10 is validated
but excluded. No image access, fitting, threshold optimization or uploads occur.
"""
import argparse
import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sys

VERSION = "participant-proposal-v0.1"
KEY = ["Subject_id", "Study_id", "Predict_class"]
TRUTH_COLUMNS = KEY + ["Target"]
SUBMISSION_COLUMNS = KEY + ["Probability", "Gate"]
OUTPUT_CLASSES = tuple(str(i) for i in range(1, 11))
SCORE_CLASSES = OUTPUT_CLASSES[:9]
DECIMAL_PATTERN = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")


def rank_key(value):
    """Quantize a float64 result's standard decimal string, ROUND_HALF_UP."""
    return str(Decimal(str(value)).quantize(Decimal("0.000000000001"), rounding=ROUND_HALF_UP))


def _decimal_field(text, name, location):
    if not DECIMAL_PATTERN.fullmatch(text):
        raise ValueError(f"{location}: {name} must be a finite decimal number")
    try:
        exact = Decimal(text)
    except InvalidOperation as error:
        raise ValueError(f"{location}: invalid {name}") from error
    if not exact.is_finite() or not Decimal(0) <= exact <= Decimal(1):
        raise ValueError(f"{location}: {name} must be in [0,1]")
    value = float(exact)
    if not math.isfinite(value):
        raise ValueError(f"{location}: non-finite {name}")
    return value, exact


def _read_table(path, expected_columns):
    path = Path(path)
    content = path.read_bytes()
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ValueError(f"{path.name}: expected UTF-8 CSV") from error
    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    records, studies = {}, {}
    try:
        header = next(reader, None)
        if header != expected_columns:
            raise ValueError(f"{path.name}: expected columns in this exact order: {expected_columns}")
        for values in reader:
            location = f"{path.name}: CSV line {reader.line_num}"
            if len(values) != len(expected_columns):
                raise ValueError(f"{location}: wrong field count")
            row = dict(zip(header, values))
            for name in KEY[:2]:
                value = row[name]
                if not value or value != value.strip() or any(ord(c) < 32 or ord(c) == 127 for c in value):
                    raise ValueError(f"{location}: {name} must be a nonempty ID without edge whitespace/control characters")
            if row["Predict_class"] not in OUTPUT_CLASSES:
                raise ValueError(f"{location}: Predict_class must be exactly one of 1..10")
            key = tuple(row[name] for name in KEY)
            if key in records:
                raise ValueError(f"{location}: duplicate Subject/Study/class key")
            subject, study, class_id = key
            if study in studies and studies[study][0] != subject:
                raise ValueError(f"{location}: Study_id maps to more than one Subject_id")
            studies.setdefault(study, (subject, set()))[1].add(class_id)
            if "Target" in header:
                if row["Target"] not in ("0", "1"):
                    raise ValueError(f"{location}: Target must be exactly 0 or 1; unknown labels are not negatives")
                row["Target"] = int(row["Target"])
            else:
                row["Probability"], _ = _decimal_field(row["Probability"], "Probability", location)
                row["Gate"], row["_exact_gate"] = _decimal_field(row["Gate"], "Gate", location)
            records[key] = row
    except csv.Error as error:
        raise ValueError(f"{path.name}: CSV line {reader.line_num}: {error}") from error
    if not records:
        raise ValueError(f"{path.name}: no data rows")
    for study, (_, classes) in studies.items():
        if classes != set(OUTPUT_CLASSES):
            missing = sorted(set(OUTPUT_CLASSES) - classes, key=int)
            raise ValueError(f"{path.name}: Study_id {study!r} is missing output classes {missing}; all ten are required")
    return records, hashlib.sha256(content).hexdigest()


def _binary_metrics(targets, probabilities, gates, class_id):
    positives, count = sum(targets), len(targets)
    negatives = count - positives
    if not positives or not negatives:
        raise ValueError(f"class {class_id}: AUC is undefined without both positive and negative studies; scoring must pause")
    # Ascending groups count positive/negative pairs. Equal probabilities get
    # exactly half credit; integer twice-concordance avoids tie-rank rounding.
    ordered = sorted(zip(probabilities, targets))
    twice_concordant, negatives_below, index = 0, 0, 0
    while index < count:
        end = index + 1
        while end < count and ordered[end][0] == ordered[index][0]:
            end += 1
        group_positive = sum(y for _, y in ordered[index:end])
        group_negative = end - index - group_positive
        twice_concordant += 2 * group_positive * negatives_below + group_positive * group_negative
        negatives_below += group_negative
        index = end
    auc = twice_concordant / (2 * positives * negatives)
    decisions = [p >= g for p, g in zip(probabilities, gates)]
    tp = sum(y == 1 and decision for y, decision in zip(targets, decisions))
    fp = sum(y == 0 and decision for y, decision in zip(targets, decisions))
    fn = sum(y == 1 and not decision for y, decision in zip(targets, decisions))
    denominator = 2 * tp + fp + fn
    f1 = 2 * tp / denominator if denominator else 0.0
    return dict(auc=auc, f1=f1, positives=positives, negatives=negatives, TP=tp, FP=fp, FN=fn)


def score(truth_path, submission_path):
    """Validate complete input files and return the proposed nine-class metrics."""
    truth, truth_hash = _read_table(truth_path, TRUTH_COLUMNS)
    prediction, prediction_hash = _read_table(submission_path, SUBMISSION_COLUMNS)
    if truth.keys() != prediction.keys():
        missing, extra = set(truth) - set(prediction), set(prediction) - set(truth)
        raise ValueError(f"Submission key grid differs from truth: missing={len(missing)}, extra={len(extra)}")
    gates = {}
    for key, row in prediction.items():
        class_id = key[2]
        exact = row["_exact_gate"]
        if class_id in gates and exact != gates[class_id]:
            raise ValueError(f"class {class_id}: Gate must be fixed across all studies")
        gates[class_id] = exact
    details = {}
    # Sorting makes the implementation independent of input CSV row ordering.
    for class_id in SCORE_CLASSES:
        keys = sorted(key for key in truth if key[2] == class_id)
        details[class_id] = _binary_metrics(
            [truth[key]["Target"] for key in keys],
            [prediction[key]["Probability"] for key in keys],
            [prediction[key]["Gate"] for key in keys], class_id)
    # Python floats use binary64; fsum defines reproducible, accurate summation.
    macro_auc = math.fsum(d["auc"] for d in details.values()) / len(SCORE_CLASSES)
    macro_f1 = math.fsum(d["f1"] for d in details.values()) / len(SCORE_CLASSES)
    display_score = 100 * macro_auc
    return dict(
        status="valid_under_proposal", scorer_version=VERSION,
        notice="Participant-proposed rules only; not a verified organizer scoring backend or leaderboard prediction.",
        output_classes=list(map(int, OUTPUT_CLASSES)), score_classes=list(map(int, SCORE_CLASSES)),
        studies=len({key[1] for key in truth}), patients=len({key[0] for key in truth}),
        macro_auc=macro_auc, macro_f1=macro_f1, display_score=display_score,
        display_score_6dp=str(Decimal(str(display_score)).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)),
        rank_keys=[rank_key(macro_auc), rank_key(macro_f1)],
        rank_order="descending numeric Decimal keys: macro_auc first, macro_f1 second; equal keys share rank",
        per_class_auc={c: d["auc"] for c, d in details.items()},
        per_class_f1={c: d["f1"] for c, d in details.items()}, per_class=details,
        fixed_gates={c: str(gates[c]) for c in OUTPUT_CLASSES},
        truth_sha256=truth_hash, submission_sha256=prediction_hash,
        semantics="Study-weighted binary ROC-AUC; ties half credit; Probability >= Gate; macro over classes 1..9",
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--truth", type=Path, required=True)
    parser.add_argument("--submission", type=Path, required=True)
    parser.add_argument("--output", type=Path, help="Optional new JSON path; existing files are not overwritten")
    args = parser.parse_args(argv)
    try:
        report = score(args.truth, args.submission)
        text = json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8") as stream:
                stream.write(text)
        else:
            print(text, end="")
    except (ValueError, OSError, ArithmeticError) as error:
        print("[INVALID] " + str(error), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
