# 建议评分器：运行与边界

这是参赛者建议草案的可执行参考，**不是已核验的主办方后台，也不预测现有榜单分数**。仅使用 Python 3.10+ 标准库，无第三方依赖、图像访问、训练或上传操作。

在本目录执行纯合成自检：

```bash
python scoring_selfcheck.py
```

所有自检文件均为临时目录内生成的虚构记录，自检结束后删除，不读取比赛数据。也可验证优化模式：

```bash
python -O scoring_selfcheck.py
```

对获授权的本地带标签评估数据运行：

```bash
python scoring_reference.py --truth truth.csv --submission submission.csv --output proposed_score.json
```

省略 `--output` 时 JSON 写到标准输出；已有输出文件拒绝覆盖。合法输入返回码 0；非法输入、未定义的计分类别 AUC 或输出冲突返回码 2，并给出原因。校验使用显式 `ValueError`，不依赖可被 `python -O` 禁用的 `assert`。

- `truth.csv` 列名与顺序：`Subject_id,Study_id,Predict_class,Target`。
- `submission.csv` 列名与顺序：`Subject_id,Study_id,Predict_class,Probability,Gate`；五列均必需。
- ID 作为字符串保留前导零；一个 Study 只能对应一个患者。双方每个 Study 都必须完整提供类别 `1` 至 `10`，且键集合完全一致，不能阈值删行。
- Target 必须明确为 `0` 或 `1`；空、未知、`-1` 不会被当作阴性。Probability/Gate 必须是有限十进制数、位于 [0,1]；每类 Gate 跨 Study 固定。
- 建议计分集合仅 `1..9`。第10类仍接受全部输入校验，但不进入 AUC、F1 或排名；计分类别缺阳性或缺阴性时拒绝出分。
- AUC 相同概率给半分；F1 用 `Probability >= Gate`；按 Study 等权、九类等权。Python binary64 计算各类指标，`math.fsum` 汇总后平均。
- `rank_keys` 为 `[Macro-AUC, Macro-F1]` 各自标准十进制字符串经 `Decimal/ROUND_HALF_UP` 保留12位的结果。应按**数值**降序比较，先AUC后F1，均相等共享名次；展示分六位小数不参与排名。
- JSON 同时保留逐类 AUC/F1、TP/FP/FN、正负例数、数据文件 SHA-256 和建议版标记。不要将含真实标识的评估输入或测试预测随代码公开。

示例实现与守则附录中的简短讲解作用不同；正式采用前，应由主办方固定评分器版本和文件哈希，并与平台进行回归核对。本文不改变既有赛事已公布的计分、舍入或并列规则。
