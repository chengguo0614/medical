# 公开初始化来源清单

本表仅列保留五成员、Small 固定替换候选及 Base20 实验所用的公开初始化。整理依据为既有训练配置、模型卡、下载审计和适配报告；**本次未联网重新检查链接可达性、许可证版本或上游文件是否变化，也未下载任何权重**。本仓库不分发这些原始或微调权重。

## 名称、数据与公开链接

| 用途 | 公开初始化名称 | 上游主数据 | 原始权重公开链接 | 来源说明 |
|---|---|---|---|---|
| 保留成员 R18 | torchvision `ResNet18_Weights.IMAGENET1K_V1` | ImageNet-1k，自然图像 | [resnet18-f37072fd.pth](https://download.pytorch.org/models/resnet18-f37072fd.pth) | [torchvision 模型文档](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.resnet18.html) |
| 保留成员 DN121 | torchvision `DenseNet121_Weights.IMAGENET1K_V1` | ImageNet-1k，自然图像 | [densenet121-a639ec97.pth](https://download.pytorch.org/models/densenet121-a639ec97.pth) | [torchvision 模型文档](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.densenet121.html) |
| 保留成员 Tiny EMA e4 | torchvision `ConvNeXt_Tiny_Weights.IMAGENET1K_V1` | ImageNet-1k，自然图像 | [convnext_tiny-983f1562.pth](https://download.pytorch.org/models/convnext_tiny-983f1562.pth) | [torchvision 模型文档](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.convnext_tiny.html) |
| 保留成员 Tiny 普通 e8 | `timm/convnext_tiny.fb_in22k_ft_in1k`，revision `bc48a87f119bae1b06418f5340bfa97ef75d4609` | ImageNet-22k 预训练，再在 ImageNet-1k 微调 | [固定 revision 的 model.safetensors](https://huggingface.co/timm/convnext_tiny.fb_in22k_ft_in1k/resolve/bc48a87f119bae1b06418f5340bfa97ef75d4609/model.safetensors) | [固定 revision 模型卡](https://huggingface.co/timm/convnext_tiny.fb_in22k_ft_in1k/blob/bc48a87f119bae1b06418f5340bfa97ef75d4609/README.md) |
| 保留成员 B3 普通 e10 | torchvision `EfficientNet_B3_Weights.IMAGENET1K_V1` | ImageNet-1k，自然图像 | [efficientnet_b3_rwightman-b3899882.pth](https://download.pytorch.org/models/efficientnet_b3_rwightman-b3899882.pth) | [torchvision 模型文档](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.efficientnet_b3.html) |
| Small 普通 e5 候选 | torchvision `ConvNeXt_Small_Weights.IMAGENET1K_V1` | ImageNet-1k，自然图像 | [convnext_small-0c510722.pth](https://download.pytorch.org/models/convnext_small-0c510722.pth) | [torchvision 模型文档](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.convnext_small.html) |
| Base20 实验 | `timm/convnext_base.fb_in22k_ft_in1k`，revision `67758fcbcf9f007ec7630bf8636b74a8f24e52a0` | ImageNet-22k 预训练，再在 ImageNet-1k 微调 | [固定 revision 的 model.safetensors](https://huggingface.co/timm/convnext_base.fb_in22k_ft_in1k/resolve/67758fcbcf9f007ec7630bf8636b74a8f24e52a0/model.safetensors) | [固定 revision 模型卡](https://huggingface.co/timm/convnext_base.fb_in22k_ft_in1k/blob/67758fcbcf9f007ec7630bf8636b74a8f24e52a0/README.md) |

链接固定的是公开初始化，不是本项目微调后的竞赛模型。e4/e5/e8/e10 是各自训练方案的权重选择记录，不是上游预训练轮数。

## 代码许可证与权重许可证分开记录

| 来源 | 已有代码许可证据 | 已有权重许可证据及不足 |
|---|---|---|
| torchvision 五种 ImageNet-1k 初始化：R18、DN121、Tiny、B3、Small | 已保存 [torchvision v0.26.0 LICENSE](https://github.com/pytorch/vision/blob/v0.26.0/LICENSE)，BSD-3-Clause，适用于相应代码；当前部署兼容性另外核对 torch 2.10 / torchvision 0.25 | 本地历史材料有“torchvision BSD-3-Clause”的来源记录，但未保存这五个原始权重各自独立的许可证全文。**代码 BSD 不能自动证明每份权重及上游数据的全部再分发权利。** 本表保留来源，不据此作完整权重再分发授权认定；发布权重前仍须逐项补充适用条款。 |
| timm Tiny22k / Base22k | 本地将张量适配到 torchvision 架构；torchvision 代码的 BSD 与上游代码/权重许可分别处理 | 已保存的两个固定 revision 模型卡均显式标注 `license: apache-2.0`，并说明 ImageNet-22k→1k。此为权重仓库模型卡许可声明，**不是赛事逐模型批准或原始数据许可证明**。再分发前仍须保留适用许可证全文及上游通知。 |
| 本仓库自有代码 | 以根目录许可证的实际授权范围为准 | 本仓库使用 MIT 或其他自有代码许可证，均不能覆盖赛方数据、第三方代码或权重；不得把项目许可证当成全部模型权重的许可证。 |

公开可下载、代码许可证、权重许可、数据许可和赛事允许使用，是不同问题。本清单不作法律意见，也不替代主办方核验。非医学初始化及赛方监督微调的范围见 [DATA_AND_REPRODUCIBILITY.md](DATA_AND_REPRODUCIBILITY.md)。

## 已有 SHA-256 记录

以下是既有审计记录的完整 SHA-256；不是文件名中八位前缀，也不是本次重新下载核算的结果。转换初始化是为本项目架构键映射及新分类头生成的文件，**不能冒充上游原始文件哈希**。

| 初始化 | 上游原始权重 SHA-256 | 本地转换初始化 SHA-256 |
|---|---|---|
| ResNet18 ImageNet-1k | `f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec` | 无需另行映射；本表不提供未记录的转换文件哈希 |
| DenseNet121 ImageNet-1k | 既有材料未找到完整原始初始化 SHA-256；**本次未公开提供，不以文件名 `a639ec97` 补造** | 无需另行映射；未提供 |
| ConvNeXt-Tiny ImageNet-1k | `983f1562536e84ff750a1576fb08e54de751dbf2e17c0d8a4a13704341fdcd3d` | 保留 EMA 成员不使用 Tiny22k 键映射；不以其他实验转换文件混充 |
| ConvNeXt-Tiny ImageNet-22k→1k | `77b619e187de71bce58721689da0c009e84cc20677293d7d43105307e34d868a` | `9449b8fa215ddefc104bdb4d506051d37dfab3467d12e318aeaf2a331534e047` |
| EfficientNet-B3 ImageNet-1k | `b3899882250c22946d0229d266049fcd133c169233530b36b9ffa7983988362f` | 无需另行映射；未提供 |
| ConvNeXt-Small ImageNet-1k | `0c510722adfd92966a2bd72b92f785ca05966bbac03cafe2f7a90b1f54bfab9a` | 无需另行映射；未提供 |
| ConvNeXt-Base ImageNet-22k→1k | `4853efc8d5dd3ed9b0f888a9c601d7556373599f944f9ac79af8b8ec81aa7381` | `5149c1d89e6d30389f16d59865f17c56d2007d6cff895fb46185da635ee70908` |

Tiny22k 适配记录为 182 项张量映射；Base22k 为 344 项。映射核验及同输入前向一致只检验实现适配，不证明与上游原生预处理完全等价，也不证明竞赛收益。初始化哈希不等于微调 checkpoint 哈希；本仓库不提供可下载 checkpoint，不能据此声称模型发布已完成。

上述来源依赖本地保存的训练配置、`adaptation_report.json`、B3 `initialization_audit.json`、Small 来源文档及原始模型卡，完整文件未随包附带。可公开结果的证据绑定范围见 [aggregate_results.json](../reports/aggregate_results.json)；没有对未公开底层报告提供虚假的公开证明链接。
