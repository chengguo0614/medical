# 便携参考代码使用说明

本代码用于复现方法与检查实现，不承诺复现历史 77.10 成绩或逐位相同的 CSV。历史运行包含缓存、GPU 重采样、不同公开初始化、固定融合算术和官方环境检查；这里使用 CPU/Pillow 预处理及直接 float32 加权平均，历史权重也未随仓库公开。它不是可直接上传比赛的最终提交包。

## 安装与无真实数据检查

从仓库根目录使用 Python 3.10 或更新版本，安装一对相互兼容的 torch/torchvision。示例：

```bash
python -m pip install -r requirements.txt
python -m cxr_reference.smoke
```

smoke 在系统临时目录生成随机像素、明确标记为 MOCK 的标识、临时模型和 CSV，完成一轮 CPU 小规模训练及评估，然后清理临时目录。无需数据、GPU、网络或预训练下载。它不检验医学准确率、CUDA FP16、官方环境或 T4 性能。

## 数据接口与患者划分

输入 CSV 每行对应一张图片，包含 `Subject_id,Study_id,Dicom_id,ViewPosition`；有标签时增加 `Predict_class`，如 `1;4`。不同疾病可同时阳性；第 10 类也只是一个明确的输出类别，不擅自补为其他类别的反事件。每个 study 的所有行必须具有相同标签且归属唯一患者。CSV 标识按字符串读取，保留前导零。

标签解析采用**完全标注的闭集假设：列出的类为 1，未列出的类为 0**。不支持未知、未标注或不确定标签，也不把这些状态自动当作阴性。若原始数据存在这些情况，须先使用独立、明确的标签掩码方案，本参考实现不能直接用于该数据。

图片默认位于 `IMAGE_ROOT/Subject_id/Study_id/Dicom_id.jpg`，支持 `.jpg/.jpeg/.png` 及对应大写扩展名。也可在原始 CSV 提供相对 `IMAGE_ROOT` 的 `relative_path`。路径必须在所指定图片根目录内，且每个 ID 唯一定位图片。

```bash
python -m cxr_reference.prepare_data --csv data/development.csv --image-root data/images --output outputs/prepared --folds 4 --seed 42
```

得到 `manifest.csv`、`audit.json` 和各 `foldN/train.csv,valid.csv`。划分只按患者，采用患者标签贪心平衡与种子固定的同分顺序；不是原历史折文件。准备过程解码输入图片、检查准确的灰度像素重复；它不是近重复检测器，也不自动判断不同独立目录之间是否重复。

准备推理元数据时省略 `--folds`，便不会用标签产生训练划分。不要把测试数据用于训练/选择/阈值拟合。代码不会自动读取任何名为 test 的目录。

## 有限训练与内部选择

```bash
python -m cxr_reference.train --train-manifest outputs/prepared/fold0/train.csv --inner-manifest outputs/prepared/fold0/valid.csv --output runs/reference --architecture convnext_small --image-size 448 --long-side 640 --epochs 8 --micro-batch 8 --effective-batch 32 --learning-rate 0.0001 --weight-decay 0.05 --stochastic-depth 0.3 --stage-lr-decay 0.8 --exclude-norm-bias-decay --ema-decay 0.999 --selection inner_all_ge5 --score-classes 1,2,3,4,5,6,7,8,9,10 --device cuda --amp
```

该命令默认从随机初始化开始，不会下载权重。上面只展示接口与一个历史相似的联合配方，并非推荐的新试验或有提分保证的配方。`--stage-lr-decay` 目前仅支持 ConvNeXt，bias 和一维参数可排除 WD。没有选择集时用 `--selection fixed_last`，不提供 `--inner-manifest`。只有内部普通权重指标可用于 `inner_all` 或 `inner_all_ge5` 选轮；EMA 只写为次要指标；相同分数保留先出现的轮次。训练器核对 train/inner 的患者、study、image 标识及解析后的路径互斥，避免换 ID 引用同一图片。不同路径的重复像素/近重复仍需另做审计。

最终外层评估患者须与训练及内部选择患者都互斥。评估器只有标签 manifest 和概率 CSV，**不能证明外层患者未被模型训练或用于选择**；使用者必须核验所有成员的训练/inner 清单与数据流程，并公开其局限。本仓 smoke 是同一内部集上的接口测试，绝非独立验证。

支持 resnet18、densenet121、convnext_tiny/small/base、efficientnet_b3 的 torchvision 架构。随机从头训练与使用公开预训练是完全不同的起点。若自行取得有许可的兼容 torchvision ImageNet `state_dict`，可增加：

```bash
--initialization checkpoints/public_init.pth --initialization-sha256 FULL_64_HEX_SHA256 --initialization-description "上游模型及通用训练数据说明" --initialization-license "已核验许可证名称" --initialization-url "https://公开可访问的来源"
```

只允许输出层维度不匹配后重新初始化，其余张量必须完整匹配。声明由使用者提供，哈希一致不等于许可证已获独立验证。本实现不支持自动适配 timm 初始化、不下载或使用医学权重。

每 epoch 从每个 study 选一张图训练，种子固定；轻增强为小仿射及亮度/对比度。训练使用 BCE、AdamW、实际窗口样本数归一的梯度累积、warmup cosine、EMA。末尾不满 effective batch 的更新按真实样本数归一。CUDA AMP 只在真实优化器更新后更新 EMA 和调度；若出现跳过更新，程序保留证据但拒绝把它标为完整固定更新终点。

输出每轮普通/EMA、历史、配置、输入 manifest SHA 和最终 `selection.json`。不覆盖已存在 run，不实现自动恢复；不能用本参考脚本盲重启历史活动训练。恢复、容量回退、计划冻结/远程调度属于原运行控制层，未公开复制。可见性与可读性优先，本参考会保存所有 epoch，因此不适合直接当作 500 MB 提交目录。

## 固定推理与 CSV

下例假定 `data/outer.csv` 是在任何训练和内部选轮之前按患者预留、且获准用于评估的带标签外层数据。它与上述 development 数据互斥；不能把测试集改名为 outer，也不能在本轮训练全集上计算后声称泛化结果。先独立准备其清单，不做折划分：

```bash
python -m cxr_reference.prepare_data --csv data/outer.csv --image-root data/images --output outputs/outer
python -m cxr_reference.predict --checkpoint runs/reference/epoch_05.pt --manifest outputs/outer/manifest.csv --output outputs/predictions.csv --device cuda --amp
```

使用 `selection.json` 实际指明的文件；示例的 e5 不代表应该事后挑 e5。推理对所有图片逐图前向，固定 `eval`，无梯度、无 BN 更新、无测试适配。输出全部十类五列长表 `Subject_id,Study_id,Predict_class,Probability,Gate`，Gate 固定 0.5；写出前检查概率范围、完整网格和浮点 round-trip。

study 聚合在 checkpoint 中固定：`frontal75` 为 AP/PA 均值占 0.75，其他视角占 0.25；只有一组时使用该组，只有未知/其他视角时用现有图片均值。`mean` 是另一显式模式，不自动扫描或选择。PNG/JPEG 解码使用同一 Pillow 接口；支持解码不等于已通过真实原生 PNG 精度或 T4 验收。

多模型固定融合可使用 `--ensemble ensemble.json`，相对路径以 JSON 所在目录为基准：

```json
{
  "aggregation": "frontal75",
  "members": [
    {"checkpoint": "runs/a/epoch_08.pt", "state": "ordinary", "weight": 0.6, "sha256": "在此填该文件完整哈希"},
    {"checkpoint": "runs/b/epoch_08.pt", "state": "ema", "weight": 0.4, "sha256": "在此填该文件完整哈希"}
  ]
}
```

权重必须正且总和为 1，所有成员聚合规则一致。参考推理只接受带 `reference_only=true` 明确预处理元数据的本参考 checkpoint，不把旧 checkpoint 静默当作兼容文件。`--state ema` 只作用于单 checkpoint 模式；ensemble 每成员明确写 state。

## 明确评分范围与患者统计

```bash
python -m cxr_reference.evaluate --manifest outputs/outer/manifest.csv --predictions outputs/predictions.csv --baseline outputs/baseline.csv --score-classes 1,2,3,4,5,6,7,8,9 --bootstrap 1000 --seed 42 --output outputs/comparison_nine_classes.json
```

评估要求 caller 显式选择类别；若需要历史十类口径，用 `1,2,3,4,5,6,7,8,9,10` 并另存新结果。九类和十类不可改名混用，也不能借新口径覆写历史指标。输入 CSV 必须与标签 study/患者/十类网格完全一致。

输出全体、当前评估集中每患者至少 5/10 个 study 的描述性结果，以及固定模型的患者整簇配对 bootstrap（有 baseline 时为候选减对照，无 baseline 时为候选 AUC）。每次整簇重采样患者；某次缺少任一评分分类的正负样本则排除该次，报告有效次数，不能把缺失类默默从宏平均中删掉。

95% 区间仅在有效 bootstrap 次数至少 200 且占请求次数至少 80% 时报告；不足则 `interval95=null` 并标记 `insufficient_valid_bootstrap_draws`。这只是防止极少有效重采样下输出伪精确区间，不保证稀有类、少患者或反复选型下的统计可靠性。

高频组按当前 labelled manifest 计算，不能解释为患者终生历史，更不能把该组 AUC 直接当作线上分数。区间不包括训练或反复选型的不确定性；复用开发集和多重比较需在报告中披露。该脚本不自动决定继续训练或上线。

## 验证边界

已运行检查见 `provenance/code_validation.json`。源码编译和合成 CPU 端到端通过，证明入口能配合工作；没有发布真实患者行级信息、图像、模型权重或历史提交 CSV。没有运行官方 T4/100 图/5 图计时，也未提供可冒充官方 `cost.py` 的简化毫秒数字。真正提交前仍需相同最终推理路径下的官方计时、材料/文件大小与预测一致性验收。
