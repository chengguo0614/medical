"""Portable research reference; no competition data or weights are included."""

__version__ = "0.1.0"
