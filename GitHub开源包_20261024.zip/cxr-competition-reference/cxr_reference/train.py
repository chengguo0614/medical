"""Finite single-model training with optional patient-disjoint inner selection."""
import argparse
from contextlib import nullcontext
import math
from pathlib import Path
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
import torchvision

from .common import parse_classes, resolve_device, seed_all, sha256, write_json
from .data import StudyDataset, aggregate, assert_disjoint, seed_worker
from .metrics import cohort_masks, metrics
from .models import ARCHITECTURES, ModelEMA, build_model, load_initialization, parameter_groups


def autocast(device, amp):
    return torch.autocast("cuda", dtype=torch.float16) if amp else nullcontext()


def loader(dataset, batch, workers, training, seed):
    return DataLoader(dataset, batch_size=batch, shuffle=training, num_workers=workers,
                      pin_memory=False, worker_init_fn=seed_worker,
                      generator=torch.Generator().manual_seed(seed), drop_last=False)


def validate(model, dataset, args, device):
    model.eval()
    probabilities, indices = [], []
    with torch.inference_mode():
        for images, _, index in loader(dataset, args.micro_batch, args.workers, False, args.seed):
            with autocast(device, args.amp):
                logits = model(images.to(device))
            probabilities.append(logits.float().sigmoid().cpu().numpy())
            indices.append(index.numpy())
    indices = np.concatenate(indices)
    p = aggregate(np.concatenate(probabilities), indices, dataset.frame.ViewPosition, len(dataset.studies), args.aggregation)
    result = {}
    for name, mask in cohort_masks(dataset.studies.Subject_id).items():
        result[name] = metrics(dataset.labels[mask], p[mask], args.score_classes) if mask.any() else None
    return result


def run(args):
    if args.epochs < 1 or args.micro_batch < 1 or args.effective_batch < args.micro_batch:
        raise ValueError("Invalid epochs/batch sizes")
    if args.effective_batch % args.micro_batch:
        raise ValueError("effective-batch must be divisible by micro-batch")
    if args.selection != "fixed_last" and args.inner_manifest is None:
        raise ValueError("Inner selection requires an explicit patient-disjoint --inner-manifest")
    if args.initialization is not None and not all([args.initialization_sha256, args.initialization_description, args.initialization_license]):
        raise ValueError("Local initialization requires SHA256, source/data description and license declaration")
    if args.output.exists():
        raise FileExistsError("Use a new run directory; this reference does not silently resume/overwrite")
    device = resolve_device(args.device)
    if args.amp and device.type != "cuda":
        raise ValueError("--amp uses CUDA FP16; omit it on CPU")
    if args.workers < 0 or args.image_size < 32 or args.long_side < 0 or args.threads < 1 or args.max_gradient_norm <= 0:
        raise ValueError("Invalid worker count or preprocessing dimensions")
    seed_all(args.seed)
    torch.set_num_threads(args.threads)
    training = StudyDataset(args.train_manifest, args.image_size, args.long_side, True, args.seed, labelled=True)
    inner = (StudyDataset(args.inner_manifest, args.image_size, args.long_side, labelled=True)
             if args.inner_manifest else None)
    if inner is not None:
        assert_disjoint(training.frame, inner.frame)
    model = build_model(args.architecture, args.stochastic_depth)
    initialization = (load_initialization(model, args.initialization, args.initialization_sha256)
                      if args.initialization else {"method": "random initialization; no download"})
    model = model.to(device)
    ema = ModelEMA(model, args.ema_decay)
    optimizer = torch.optim.AdamW(parameter_groups(model, args.architecture, args.learning_rate,
                      args.weight_decay, args.stage_lr_decay, args.exclude_norm_bias_decay))
    accumulation = args.effective_batch // args.micro_batch
    updates_per_epoch = math.ceil(len(training) / args.effective_batch)
    total_updates = updates_per_epoch * args.epochs
    warmup_updates = min(args.warmup_updates, max(0, total_updates - 1))
    if warmup_updates < 0:
        raise ValueError("warmup-updates must be nonnegative")

    def schedule(step):
        if warmup_updates and step < warmup_updates:
            return (step + 1) / warmup_updates
        progress = (step - warmup_updates) / max(1, total_updates - warmup_updates - 1)
        return .05 + .95 * .5 * (1 + math.cos(math.pi * min(max(progress, 0), 1)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, schedule)
    scaler = torch.amp.GradScaler("cuda", enabled=args.amp)
    config = dict(model=args.architecture, stochastic_depth=args.stochastic_depth, image_size=args.image_size,
                  long_side=args.long_side, normalization="imagenet", class_ids=list(range(1, 11)),
                  aggregation=args.aggregation, preprocessing="EXIF; grayscale; Pillow LANCZOS thumbnail; RGB BILINEAR letterbox",
                  score_classes=args.score_classes, selection=args.selection, seed=args.seed,
                  epochs=args.epochs, micro_batch=args.micro_batch, effective_batch=args.effective_batch,
                  learning_rate=args.learning_rate, weight_decay=args.weight_decay, stage_lr_decay=args.stage_lr_decay,
                  exclude_norm_bias_decay=args.exclude_norm_bias_decay, ema_decay=args.ema_decay,
                  amp=args.amp, total_planned_updates=total_updates, warmup_updates=warmup_updates,
                  train_manifest_sha256=sha256(args.train_manifest),
                  inner_manifest_sha256=sha256(args.inner_manifest) if args.inner_manifest else None,
                  initialization=initialization, initialization_description=args.initialization_description,
                  initialization_license=args.initialization_license, initialization_url=args.initialization_url,
                  torch=str(torch.__version__), torchvision=str(torchvision.__version__),
                  reference_only=True, bitwise_historical_reproduction=False)
    args.output.mkdir(parents=True)
    write_json(args.output / "config.json", config)
    history, completed_updates, attempted_updates, best_score, best_epoch = [], 0, 0, -float("inf"), None
    started = time.monotonic()
    for epoch in range(1, args.epochs + 1):
        training.epoch = epoch - 1
        batches = loader(training, args.micro_batch, args.workers, True, args.seed + epoch)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss_total, samples, window_samples = 0., 0, 0
        for batch_index, (images, labels, _) in enumerate(batches):
            images, labels = images.to(device), labels.to(device)
            with autocast(device, args.amp):
                loss = torch.nn.functional.binary_cross_entropy_with_logits(model(images), labels, reduction="mean")
            if not torch.isfinite(loss):
                raise FloatingPointError("Nonfinite loss; preserve the failed run and inspect inputs")
            # Sum per-study gradients; divide by actual window size at the update,
            # including the final partial window. No underweighted last update.
            scaler.scale(loss * len(images)).backward()
            window_samples += len(images)
            loss_total += float(loss.detach()) * len(images)
            samples += len(images)
            boundary = (batch_index + 1) % accumulation == 0 or batch_index + 1 == len(batches)
            if boundary:
                scaler.unscale_(optimizer)
                for parameter in model.parameters():
                    if parameter.grad is not None:
                        parameter.grad.div_(window_samples)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_gradient_norm)
                before = scaler.get_scale()
                scaler.step(optimizer)
                scaler.update()
                attempted_updates += 1
                if scaler.get_scale() >= before:
                    completed_updates += 1
                    ema.update(model)
                    scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                window_samples = 0
        ordinary = validate(model, inner, args, device) if inner else None
        secondary = validate(ema.model, inner, args, device) if inner else None
        score = None
        if args.selection == "inner_all":
            score = ordinary["all"]["macro_auc"]
        elif args.selection == "inner_all_ge5":
            a, g = ordinary["all"]["macro_auc"], ordinary["ge5"]
            if g is not None and a is not None and g["macro_auc"] is not None:
                score = .5 * (a + g["macro_auc"])
        if args.selection != "fixed_last" and score is None:
            raise ValueError("Selection metric undefined; do not silently drop classes/cohorts")
        if score is not None and score > best_score:
            best_score, best_epoch = score, epoch
        if args.selection == "fixed_last":
            best_epoch = epoch
        state = dict(config=config, epoch=epoch, effective_updates=completed_updates,
                     model={k: v.detach().cpu() for k, v in model.state_dict().items()},
                     ema={k: v.detach().cpu() for k, v in ema.model.state_dict().items()}, ema_updates=ema.updates)
        checkpoint = args.output / f"epoch_{epoch:02d}.pt"
        temporary = checkpoint.with_suffix(".tmp")
        torch.save(state, temporary)
        temporary.replace(checkpoint)
        row = dict(epoch=epoch, training_bce=loss_total / samples, ordinary_inner=ordinary, ema_inner_secondary=secondary,
                   selection_score=score, effective_updates=completed_updates, attempted_updates=attempted_updates)
        history.append(row)
        write_json(args.output / "history.json", history)
        print("epoch", epoch, "bce", round(row["training_bce"], 6), "updates", completed_updates, flush=True)
    if completed_updates != total_updates:
        raise RuntimeError("AMP skipped updates; preserve this run, and do not call it a completed fixed-update endpoint")
    chosen = args.output / f"epoch_{best_epoch:02d}.pt"
    write_json(args.output / "selection.json", dict(status="completed", selected_epoch=best_epoch,
               checkpoint=chosen.name, checkpoint_sha256=sha256(chosen), selection=args.selection,
               score_classes=args.score_classes, effective_updates=completed_updates,
               elapsed_seconds=time.monotonic() - started, outer_or_test_used=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-manifest", type=Path, required=True)
    parser.add_argument("--inner-manifest", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--architecture", choices=ARCHITECTURES, default="resnet18")
    parser.add_argument("--initialization", type=Path)
    parser.add_argument("--initialization-sha256")
    parser.add_argument("--initialization-description", help="Verified upstream dataset/process and model name")
    parser.add_argument("--initialization-license")
    parser.add_argument("--initialization-url")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--image-size", type=int, default=320)
    parser.add_argument("--long-side", type=int, default=640)
    parser.add_argument("--micro-batch", type=int, default=8)
    parser.add_argument("--effective-batch", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--stage-lr-decay", type=float, default=1.)
    parser.add_argument("--exclude-norm-bias-decay", action="store_true")
    parser.add_argument("--stochastic-depth", type=float, default=.1)
    parser.add_argument("--ema-decay", type=float, default=.999)
    parser.add_argument("--warmup-updates", type=int, default=100)
    parser.add_argument("--max-gradient-norm", type=float, default=5.)
    parser.add_argument("--aggregation", choices=["mean", "frontal75"], default="frontal75")
    parser.add_argument("--selection", choices=["fixed_last", "inner_all", "inner_all_ge5"], default="fixed_last")
    parser.add_argument("--score-classes", type=parse_classes, required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--amp", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
