"""Audit a caller-supplied split and create reproducible patient-level folds."""
import argparse
import hashlib
import os
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageOps

from .common import sha256, write_json
from .data import IDENTIFIERS, label_vector, validate_metadata


def resolve_image(root, row):
    if hasattr(row, "relative_path") and row.relative_path:
        candidates = [root / row.relative_path]
    else:
        parent = root / row.Subject_id / row.Study_id
        candidates = [parent / (row.Dicom_id + ext) for ext in (".jpg", ".jpeg", ".png", ".JPG", ".JPEG", ".PNG")]
    found = []
    for candidate in candidates:
        path = candidate.resolve()
        path.relative_to(root)  # Reject traversal and symlinks outside the supplied image root.
        if path.is_file():
            found.append(path)
    if len(set(found)) != 1:
        raise ValueError("Image must resolve uniquely: " + str(row.Dicom_id))
    return found[0]


def patient_folds(frame, folds, seed):
    if folds < 2 or folds > frame.Subject_id.nunique():
        raise ValueError("folds must be between 2 and patient count")
    patient_labels = {}
    for pid, group in frame.groupby("Subject_id"):
        patient_labels[pid] = np.maximum.reduce([label_vector(v) for v in group.Predict_class])
    totals = np.sum(list(patient_labels.values()), axis=0)
    rng = np.random.default_rng(seed)
    tie_order = {pid: float(rng.random()) for pid in sorted(patient_labels)}
    order = sorted(patient_labels, key=lambda pid: (-sum(patient_labels[pid]), tie_order[pid]))
    counts, sizes, assignment = np.zeros((folds, 10)), np.zeros(folds), {}
    for pid in order:
        labels = patient_labels[pid]
        scores = ((counts + 1) / (totals + 1) * labels).sum(axis=1) + .01 * sizes / len(order)
        fold = int(np.argmin(scores))
        assignment[pid] = fold
        counts[fold] += labels
        sizes[fold] += 1
    return assignment


def run(args):
    root, output = args.image_root.resolve(), args.output.resolve()
    if output.exists():
        raise FileExistsError("Choose a new output directory: " + str(output))
    frame = validate_metadata(pd.read_csv(args.csv, dtype=str, keep_default_na=False), args.folds is not None)
    paths = [resolve_image(root, row) for row in frame.itertuples(index=False)]
    if len(set(paths)) != len(paths):
        raise ValueError("Multiple image IDs resolve to the same file")
    pixel_hashes = {}
    for row, path in zip(frame.itertuples(), paths):
        with Image.open(path) as image:
            gray = ImageOps.exif_transpose(image).convert("L")
            digest = hashlib.sha256(str(gray.size).encode() + gray.tobytes()).hexdigest()
        pixel_hashes.setdefault(digest, []).append(row.Dicom_id)
    duplicates = [ids for ids in pixel_hashes.values() if len(ids) > 1]
    if duplicates and args.folds is not None:
        raise ValueError("Exact grayscale duplicates detected; resolve before patient splitting")
    output.mkdir(parents=True)
    frame = frame.drop(columns=[c for c in ("original_path", "cache_path", "image_path", "relative_path") if c in frame]).copy()

    def save_manifest(selected, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        selected = selected.copy()
        selected["image_path"] = [os.path.relpath(paths[i], path.parent) for i in selected.index]
        selected.to_csv(path, index=False)

    save_manifest(frame, output / "manifest.csv")
    assignment = patient_folds(frame, args.folds, args.seed) if args.folds else None
    if assignment is not None:
        for fold in range(args.folds):
            valid = frame.Subject_id.map(assignment).eq(fold)
            save_manifest(frame[~valid], output / f"fold{fold}" / "train.csv")
            save_manifest(frame[valid], output / f"fold{fold}" / "valid.csv")
    report = dict(images=len(frame), studies=int(frame.Study_id.nunique()), patients=int(frame.Subject_id.nunique()),
                  source_csv_sha256=sha256(args.csv), folds=args.folds, seed=args.seed,
                  exact_grayscale_duplicate_groups=duplicates,
                  duplicate_check="EXIF-corrected native-resolution grayscale bytes; not a near-duplicate detector",
                  split_method="patient-level greedy class balance with seeded tie ordering" if assignment else None,
                  assignment=assignment, manifest_sha256=sha256(output / "manifest.csv"))
    write_json(output / "audit.json", report)
    print("Prepared", len(frame), "images;", frame.Subject_id.nunique(), "patients")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--folds", type=int, help="Only for labelled development data; omitted means no splitting")
    parser.add_argument("--seed", type=int, default=42)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
