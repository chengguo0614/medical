"""Manifest validation, deterministic preprocessing and study aggregation.

This CPU/Pillow reference is intentionally distinct from the historical CUDA
resampling and CUDA Graph deployment path. It does not reproduce that path's bits.
"""
import random
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageOps
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.transforms import InterpolationMode

CLASS_IDS = list(range(1, 11))
IDENTIFIERS = ["Subject_id", "Study_id", "Dicom_id"]
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


def label_vector(value):
    tokens = str(value).split(";")
    ids = [int(token) for token in tokens]
    if not ids or len(set(ids)) != len(ids) or not set(ids).issubset(CLASS_IDS):
        raise ValueError("Labels must be nonempty unique semicolon-separated class IDs 1..10")
    return np.array([float(c in ids) for c in CLASS_IDS], dtype=np.float32)


def validate_metadata(frame, labelled=False):
    required = set(IDENTIFIERS + ["ViewPosition"])
    if labelled:
        required.add("Predict_class")
    if frame.empty or not required.issubset(frame.columns):
        raise ValueError("Empty metadata or missing columns: " + str(sorted(required - set(frame.columns))))
    if frame[IDENTIFIERS].eq("").any().any() or frame.Dicom_id.duplicated().any():
        raise ValueError("Empty identifiers or duplicate image IDs")
    if frame.groupby("Study_id").Subject_id.nunique().ne(1).any():
        raise ValueError("A study maps to multiple patients")
    if "Predict_class" in frame:
        canonical = [";".join(map(str, np.flatnonzero(label_vector(v)) + 1)) for v in frame.Predict_class]
        frame = frame.copy()
        frame["Predict_class"] = canonical
        if frame.groupby("Study_id").Predict_class.nunique().ne(1).any():
            raise ValueError("Conflicting labels within a study")
    return frame


def read_manifest(path, labelled=False):
    path = Path(path).resolve()
    frame = validate_metadata(pd.read_csv(path, dtype=str, keep_default_na=False), labelled)
    if "image_path" not in frame or frame.image_path.eq("").any():
        raise ValueError("Prepared manifest requires nonempty image_path")
    frame = frame.copy()
    frame["resolved_path"] = [(path.parent / p).resolve() for p in frame.image_path]
    for image in frame.resolved_path:
        if not image.is_file():
            raise FileNotFoundError(image)
    return frame


def assert_disjoint(left, right):
    for field in IDENTIFIERS:
        if set(left[field]) & set(right[field]):
            raise ValueError("Train/selection overlap in " + field)
    if "resolved_path" in left and "resolved_path" in right:
        a = {Path(value).resolve() for value in left.resolved_path}
        b = {Path(value).resolve() for value in right.resolved_path}
        if a & b:
            raise ValueError("Train/selection overlap in resolved image paths")


def decode_image(path, long_side):
    with Image.open(path) as image:
        image = ImageOps.exif_transpose(image).convert("L")
        if long_side > 0:
            image.thumbnail((long_side, long_side), Image.Resampling.LANCZOS)
        return image.convert("RGB")


class Letterbox:
    def __init__(self, size):
        self.size = size

    def __call__(self, image):
        return ImageOps.pad(image, (self.size, self.size), method=Image.Resampling.BILINEAR, color=0)


def make_transform(size, training=False):
    steps = [Letterbox(size)]
    if training:
        steps += [transforms.RandomAffine(5, translate=(.02, .02), scale=(.95, 1.05),
                     interpolation=InterpolationMode.BILINEAR, fill=0),
                  transforms.ColorJitter(brightness=.1, contrast=.1)]
    return transforms.Compose(steps + [transforms.ToTensor(), transforms.Normalize(MEAN, STD)])


class StudyDataset(Dataset):
    """One image per study during training; every image during inference."""
    def __init__(self, manifest, image_size, long_side=640, training=False, seed=42, labelled=False):
        self.frame = read_manifest(manifest, labelled)
        self.studies = self.frame.drop_duplicates("Study_id").reset_index(drop=True)
        mapping = {value: i for i, value in enumerate(self.studies.Study_id)}
        self.indices = self.frame.Study_id.map(mapping).to_numpy(dtype=np.int64)
        self.groups = [np.flatnonzero(self.indices == i).tolist() for i in range(len(self.studies))]
        self.labels = (np.stack([label_vector(v) for v in self.studies.Predict_class])
                       if "Predict_class" in self.studies else np.zeros((len(self.studies), 10), np.float32))
        self.paths = self.frame.resolved_path.tolist()
        self.training, self.seed, self.epoch = training, seed, 0
        self.long_side, self.transform = long_side, make_transform(image_size, training)

    def __len__(self):
        return len(self.studies) if self.training else len(self.frame)

    def __getitem__(self, index):
        if self.training:
            study = index
            image = random.Random(self.seed + self.epoch * 1000003 + index).choice(self.groups[study])
        else:
            image, study = index, int(self.indices[index])
        return self.transform(decode_image(self.paths[image], self.long_side)), torch.from_numpy(self.labels[study]), study


def seed_worker(_worker_id):
    seed = torch.initial_seed() % 2**32
    random.seed(seed)
    np.random.seed(seed)
    torch.set_num_threads(1)


def aggregate(probabilities, study_indices, views, study_count, mode="frontal75"):
    """AP/PA mean gets .75, other views .25 when both exist; otherwise available mean.

    'mean' is an explicit alternate fixed aggregation, never automatically chosen.
    """
    p, indices = np.asarray(probabilities), np.asarray(study_indices)
    if p.shape != (len(indices), 10) or len(views) != len(indices):
        raise ValueError("Image probabilities/indices/views have incompatible shapes")
    if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError("Probabilities must be finite and in [0,1]")
    if mode not in ("mean", "frontal75") or study_count < 1:
        raise ValueError("Unsupported aggregation or empty study set")
    if len(indices) == 0 or not np.issubdtype(indices.dtype, np.integer) or ((indices < 0) | (indices >= study_count)).any():
        raise ValueError("Invalid study indices")
    total, count = np.zeros((study_count, 10), np.float64), np.zeros(study_count, np.int64)
    np.add.at(total, indices, p)
    np.add.at(count, indices, 1)
    if (count == 0).any():
        raise ValueError("Study without predictions")
    result = (total / count[:, None]).astype(np.float32)
    if mode == "frontal75":
        frontal = np.isin(np.char.upper(np.char.strip(np.asarray(views, str))), ["AP", "PA"])
        for index in range(study_count):
            a, b = p[(indices == index) & frontal], p[(indices == index) & ~frontal]
            if len(a):
                result[index] = a.mean(axis=0) if not len(b) else .75 * a.mean(axis=0) + .25 * b.mean(axis=0)
    return result
