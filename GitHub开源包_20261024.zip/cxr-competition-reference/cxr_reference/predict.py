"""Shared fixed-parameter single-image inference and deterministic study CSV export."""
import argparse
from contextlib import nullcontext
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .common import resolve_device, sha256, write_json
from .data import aggregate, decode_image, make_transform, read_manifest
from .models import build_model

COLUMNS = ["Subject_id", "Study_id", "Predict_class", "Probability", "Gate"]


class Predictor:
    """Frozen single-image forwards; no gradients or cross-sample adaptation.

    Ensemble arithmetic is a direct weighted mean in float32. This reference does
    not implement the archived grouped90/10 arithmetic/CUDA Graph backend.
    """
    def __init__(self, checkpoint=None, ensemble=None, device="cpu", amp=False, state="ordinary"):
        if (checkpoint is None) == (ensemble is None):
            raise ValueError("Supply exactly one checkpoint or ensemble JSON")
        self.device, self.amp = resolve_device(device), amp
        if amp and self.device.type != "cuda":
            raise ValueError("AMP requires CUDA")
        if state not in ("ordinary", "ema"):
            raise ValueError("Unknown checkpoint state")
        if ensemble is not None:
            spec_path = Path(ensemble).resolve()
            spec = json.loads(spec_path.read_text(encoding="utf-8"))
            self.aggregation = spec.get("aggregation", "frontal75")
            definitions = []
            for member in spec["members"]:
                path = (spec_path.parent / member["checkpoint"]).resolve()
                definitions.append((path, float(member["weight"]), member.get("state", "ordinary"), member.get("sha256")))
        else:
            definitions = [(Path(checkpoint).resolve(), 1., state, None)]
            self.aggregation = None
        if not definitions or any(not np.isfinite(w) or w <= 0 for _, w, _, _ in definitions):
            raise ValueError("Member weights must be finite and positive")
        if abs(sum(w for _, w, _, _ in definitions) - 1.) > 1e-8:
            raise ValueError("Member weights must sum to one; no automatic renormalization")
        self.members, self.provenance = [], []
        for path, weight, chosen_state, expected_hash in definitions:
            digest = sha256(path)
            if expected_hash and digest != expected_hash.lower():
                raise ValueError("Checkpoint SHA256 mismatch")
            content = torch.load(path, map_location="cpu", weights_only=True)
            config = content["config"]
            required = {"model", "image_size", "long_side", "normalization", "class_ids", "aggregation"}
            if not required.issubset(config) or config["normalization"] != "imagenet" or config["class_ids"] != list(range(1, 11)):
                raise ValueError("Checkpoint must have explicit compatible reference preprocessing metadata")
            if not config.get("reference_only", False):
                raise ValueError("Archived checkpoints require an explicit audited conversion; not silently assumed compatible")
            if self.aggregation is None:
                self.aggregation = config["aggregation"]
            if config["aggregation"] != self.aggregation:
                raise ValueError("All checkpoints must share the specified study aggregation")
            if chosen_state not in ("ordinary", "ema"):
                raise ValueError("Unknown member state")
            model = build_model(config["model"], config.get("stochastic_depth", .1))
            model.load_state_dict(content["model" if chosen_state == "ordinary" else "ema"], strict=True)
            model = model.to(self.device).eval().requires_grad_(False)
            self.members.append((model, make_transform(config["image_size"]), config["long_side"], weight))
            self.provenance.append(dict(checkpoint_sha256=digest, architecture=config["model"],
                                        epoch=content.get("epoch"), state=chosen_state, weight=weight,
                                        image_size=config["image_size"], long_side=config["long_side"]))
        if self.aggregation not in ("mean", "frontal75"):
            raise ValueError("Unknown aggregation")

    def predict_image(self, path):
        result = np.zeros(10, np.float32)
        with torch.inference_mode():
            decoded = {}
            for model, transform, long_side, weight in self.members:
                if long_side not in decoded:
                    decoded[long_side] = decode_image(path, long_side)
                tensor = transform(decoded[long_side]).unsqueeze(0).to(self.device)
                context = torch.autocast("cuda", dtype=torch.float16) if self.amp else nullcontext()
                with context:
                    logits = model(tensor)
                result += np.float32(weight) * logits.float().sigmoid().cpu().numpy()[0]
        if not np.isfinite(result).all() or ((result < 0) | (result > 1)).any():
            raise ValueError("Invalid model probabilities")
        return result


def export_csv(studies, probabilities, output):
    output = Path(output)
    if output.exists():
        raise FileExistsError(output)
    if probabilities.shape != (len(studies), 10) or not np.isfinite(probabilities).all() or ((probabilities < 0) | (probabilities > 1)).any():
        raise ValueError("Invalid study probabilities")
    rows = [(row.Subject_id, row.Study_id, c, float(p[c - 1]), .5)
            for row, p in zip(studies.itertuples(), probabilities) for c in range(1, 11)]
    frame = pd.DataFrame(rows, columns=COLUMNS).sort_values(["Study_id", "Predict_class"]).reset_index(drop=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    frame.to_csv(temporary, index=False, float_format="%.17g", encoding="utf-8")
    check = pd.read_csv(temporary, dtype={"Subject_id": str, "Study_id": str}, float_precision="round_trip")
    if check.columns.tolist() != COLUMNS or len(check) != len(studies) * 10:
        raise ValueError("CSV structure verification failed")
    if not check[["Subject_id", "Study_id", "Predict_class"]].equals(frame[["Subject_id", "Study_id", "Predict_class"]]):
        raise ValueError("CSV identifier round-trip failed")
    if not np.array_equal(check.Probability.to_numpy(), frame.Probability.to_numpy()) or not check.Gate.eq(.5).all():
        raise ValueError("CSV numeric round-trip failed")
    temporary.replace(output)


def predict_manifest(predictor, manifest, output):
    output = Path(output)
    if output.exists() or output.with_suffix(".report.json").exists():
        raise FileExistsError("Output/report exists")
    frame = read_manifest(manifest)
    studies = frame.drop_duplicates("Study_id").reset_index(drop=True)
    lookup = {value: i for i, value in enumerate(studies.Study_id)}
    indices = frame.Study_id.map(lookup).to_numpy(dtype=np.int64)
    image_probabilities = np.stack([predictor.predict_image(path) for path in frame.resolved_path])
    probabilities = aggregate(image_probabilities, indices, frame.ViewPosition, len(studies), predictor.aggregation)
    export_csv(studies, probabilities, output)
    write_json(output.with_suffix(".report.json"), dict(csv_sha256=sha256(output), manifest_sha256=sha256(manifest),
               images=len(frame), studies=len(studies), classes=list(range(1, 11)), Gate=.5,
               members=predictor.provenance, aggregation=predictor.aggregation,
               device=str(predictor.device), amp=predictor.amp,
               training=False, BN_updates=False, test_adaptation=False, uploaded=False,
               historical_bitwise_reproduction=False))


def add_predictor_arguments(parser):
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--checkpoint", type=Path)
    group.add_argument("--ensemble", type=Path)
    parser.add_argument("--state", choices=["ordinary", "ema"], default="ordinary")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--threads", type=int, default=4)


def predictor_from_args(args):
    if args.threads < 1:
        raise ValueError("threads must be positive")
    torch.set_num_threads(args.threads)
    return Predictor(args.checkpoint, args.ensemble, args.device, args.amp, args.state)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_predictor_arguments(parser)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    predict_manifest(predictor_from_args(args), args.manifest, args.output)


if __name__ == "__main__":
    main()
