"""CPU-only synthetic integration check. No real images, labels or pretrained weights."""
from argparse import Namespace
import json
from pathlib import Path
import tempfile

import numpy as np
import pandas as pd
from PIL import Image
import torch

from .common import parse_classes, write_json
from .data import aggregate, assert_disjoint, read_manifest
from .evaluate import run as evaluate
from .predict import Predictor, predict_manifest
from .prepare_data import run as prepare
from .train import run as train
from .metrics import paired_patient_bootstrap


def check():
    torch.set_num_threads(1)
    with tempfile.TemporaryDirectory(prefix="cxr_reference_synthetic_") as folder:
        root = Path(folder)
        image_root, rows = root / "images", []
        rng = np.random.default_rng(1234)
        for patient in range(6):
            for study in range(5):
                pid, sid, iid = f"MOCK_PATIENT_{patient}", f"MOCK_STUDY_{patient}_{study}", f"MOCK_IMAGE_{patient}_{study}"
                extension = ".png" if study % 2 else ".jpg"
                path = image_root / pid / sid / (iid + extension)
                path.parent.mkdir(parents=True, exist_ok=True)
                Image.fromarray(rng.integers(0, 256, (48, 64), dtype=np.uint8)).save(path)
                labels = ";".join(str(c) for c in range(1, 11) if c % 2 == (patient + study) % 2)
                rows.append(dict(Subject_id=pid, Study_id=sid, Dicom_id=iid, ViewPosition="AP" if study % 2 else "LATERAL", Predict_class=labels))
        raw_csv = root / "synthetic.csv"
        pd.DataFrame(rows).to_csv(raw_csv, index=False)
        prepared = root / "prepared"
        prepare(Namespace(csv=raw_csv, image_root=image_root, output=prepared, folds=3, seed=42))
        train_manifest, inner_manifest = prepared / "fold0/train.csv", prepared / "fold0/valid.csv"
        a, b = read_manifest(train_manifest, True), read_manifest(inner_manifest, True)
        assert_disjoint(a, b)
        test_p = np.array([[.2] * 10, [.8] * 10, [.5] * 10], dtype=np.float32)
        assert np.allclose(aggregate(test_p, np.array([0, 0, 1]), ["PA", "LATERAL", "UNKNOWN"], 2)[0], .35)
        assert np.allclose(aggregate(test_p, np.array([0, 0, 1]), ["PA", "LATERAL", "UNKNOWN"], 2, "mean")[0], .5)
        run = root / "run"
        args = Namespace(epochs=1, micro_batch=4, effective_batch=8, selection="inner_all_ge5",
            inner_manifest=inner_manifest, initialization=None, initialization_sha256=None,
            initialization_description=None, initialization_license=None, initialization_url=None,
            output=run, device="cpu", amp=False, workers=0, image_size=32, long_side=48,
            seed=42, threads=1, train_manifest=train_manifest, architecture="resnet18",
            stochastic_depth=.1, ema_decay=.99, learning_rate=1e-4, weight_decay=1e-4,
            stage_lr_decay=1., exclude_norm_bias_decay=True, warmup_updates=1,
            aggregation="frontal75", score_classes=parse_classes("1,2,3,4,5,6,7,8,9,10"), max_gradient_norm=5.)
        train(args)
        selection = json.loads((run / "selection.json").read_text(encoding="utf-8"))
        assert selection["effective_updates"] == 3
        checkpoint = run / selection["checkpoint"]
        prediction = root / "prediction.csv"
        ordinary = Predictor(checkpoint=checkpoint, device="cpu")
        predict_manifest(ordinary, inner_manifest, prediction)
        ema = Predictor(checkpoint=checkpoint, device="cpu", state="ema")
        assert np.isfinite(ema.predict_image(b.resolved_path.iloc[0])).all()
        # Exercise the ensemble loader with separately specified fixed member states.
        ensemble_path = root / "ensemble.json"
        write_json(ensemble_path, dict(aggregation="frontal75", members=[
            dict(checkpoint=str(checkpoint), weight=.5, state="ordinary"),
            dict(checkpoint=str(checkpoint), weight=.5, state="ema")]))
        ensemble = Predictor(ensemble=ensemble_path, device="cpu")
        image = b.resolved_path.iloc[0]
        assert np.allclose(ensemble.predict_image(image), .5 * ordinary.predict_image(image) + .5 * ema.predict_image(image))
        for name, classes in (("ten", list(range(1, 11))), ("nine", list(range(1, 10)))):
            result = root / (name + ".json")
            evaluate(Namespace(output=result, manifest=inner_manifest, predictions=prediction,
                baseline=prediction, score_classes=classes, bootstrap=250, seed=42))
            value = json.loads(result.read_text(encoding="utf-8"))
            assert value["cohorts"]["all"]["bootstrap"]["point"] == 0.
            assert value["cohorts"]["all"]["bootstrap"]["interval95"] == [0., 0.]
            assert value["cohorts"]["ge5"]["studies"] == len(b)
        tiny_y = np.array([[i % 2] * 10 for i in range(4)], dtype=float)
        tiny_p = np.full((4, 10), .5)
        few = paired_patient_bootstrap(tiny_y, tiny_p, tiny_p, ["MOCK_A", "MOCK_B", "MOCK_C", "MOCK_D"], list(range(1, 11)), draws=5)
        assert few["interval95"] is None and few["interval_status"] == "insufficient_valid_bootstrap_draws"
        # Ensure patient overlap fails instead of silently treating it as validation.
        try:
            assert_disjoint(a, a)
        except ValueError:
            pass
        else:
            raise AssertionError("Overlap validation failed")
        renamed = b.copy()
        for field in ("Subject_id", "Study_id", "Dicom_id"):
            renamed[field] = "RENAMED_" + renamed[field]
        renamed["resolved_path"] = [a.resolved_path.iloc[0]] * len(renamed)
        try:
            assert_disjoint(a, renamed)
        except ValueError:
            pass
        else:
            raise AssertionError("Renamed identifiers bypassed path overlap check")
    return dict(status="passed", data="generated random pixels and MOCK identifiers only",
                device="cpu", network=False, pretrained_weights=False,
                checks=["JPEG/PNG preparation and decoding", "patient-disjoint class-balanced folds",
                        "frontal75 and mean aggregation", "one epoch CPU BCE training",
                        "actual-size gradient accumulation including partial window", "EMA ordinary/EMA checkpoint loading",
                        "inner all/ge5 selection", "fixed ensemble mean", "CSV round-trip and class grid",
                        "explicit 9/10-class metrics", "paired patient bootstrap identity case", "minimum valid bootstrap draws",
                        "identifier and resolved-path overlap rejection"],
                limits="No real-data accuracy, CUDA/AMP, official environment, historical CSV or T4 latency validation")


def main():
    print(json.dumps(check(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
