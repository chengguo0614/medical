"""Explicit macro-AUC definitions and paired patient-cluster bootstrap."""
import numpy as np
from sklearn.metrics import roc_auc_score


def metrics(targets, probabilities, classes):
    y, p = np.asarray(targets), np.asarray(probabilities)
    if y.shape != p.shape or y.ndim != 2 or y.shape[1] != 10 or len(y) == 0:
        raise ValueError("Expect nonempty aligned Nx10 labels/probabilities")
    if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any() or not np.isin(y, [0, 1]).all():
        raise ValueError("Invalid labels or probabilities")
    per_class = {}
    for c in classes:
        label = y[:, c - 1]
        auc = float(roc_auc_score(label, p[:, c - 1])) if len(np.unique(label)) == 2 else None
        per_class[str(c)] = dict(auc=auc, positives=int(label.sum()), negatives=int(len(label) - label.sum()))
    values = [entry["auc"] for entry in per_class.values()]
    return dict(macro_auc=float(np.mean(values)) if all(v is not None for v in values) else None,
                score_classes=classes, defined_classes=sum(v is not None for v in values), studies=len(y),
                per_class=per_class)


def cohort_masks(patient_ids):
    patients = np.asarray(patient_ids, str)
    unique, inverse, counts = np.unique(patients, return_inverse=True, return_counts=True)
    return {"all": np.ones(len(patients), bool), "ge5": counts[inverse] >= 5, "ge10": counts[inverse] >= 10}


def paired_patient_bootstrap(targets, candidate, baseline, patient_ids, classes, draws=1000, seed=42,
                             min_valid_draws=200, min_valid_fraction=.8):
    """Resample whole patients, preserving within-patient study dependence.

    These are intervals conditional on the fixed models and observed patients;
    they do not include training/selection uncertainty or predict leaderboard scores.
    """
    if draws < 1:
        raise ValueError("draws must be positive")
    ids = np.asarray(patient_ids, str)
    if len(ids) != len(targets):
        raise ValueError("Patient IDs not aligned")
    unique = np.unique(ids)
    groups = [np.flatnonzero(ids == value) for value in unique]
    if not groups:
        raise ValueError("Empty patient set")
    rng, values = np.random.default_rng(seed), []
    for _ in range(draws):
        indices = np.concatenate([groups[i] for i in rng.integers(0, len(groups), size=len(groups))])
        a = metrics(targets[indices], candidate[indices], classes)["macro_auc"]
        b = metrics(targets[indices], baseline[indices], classes)["macro_auc"] if baseline is not None else 0.
        if a is not None and b is not None:
            values.append(a - b)
    a = metrics(targets, candidate, classes)["macro_auc"]
    b = metrics(targets, baseline, classes)["macro_auc"] if baseline is not None else 0.
    enough = len(values) >= min_valid_draws and len(values) / draws >= min_valid_fraction
    return dict(point=a - b if a is not None and b is not None else None,
                interval95=np.quantile(values, [.025, .975]).tolist() if enough else None,
                interval_status="reported" if enough else "insufficient_valid_bootstrap_draws",
                minimum_valid_draws=min_valid_draws, minimum_valid_fraction=min_valid_fraction,
                requested_draws=draws, valid_draws=len(values), patients=len(unique), seed=seed,
                estimand="candidate minus baseline macro-AUC" if baseline is not None else "candidate macro-AUC",
                method="paired patient-cluster percentile bootstrap; undefined-class draws excluded",
                limitation="fixed-model conditional interval; excludes model-selection and training variability")
