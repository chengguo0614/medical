"""Use installed torchvision architectures; no backbone implementation is vendored."""
from copy import deepcopy

import torch
from torch import nn
from torchvision import models

from .common import sha256

ARCHITECTURES = ("resnet18", "densenet121", "convnext_tiny", "convnext_small", "convnext_base", "efficientnet_b3")


def build_model(architecture, stochastic_depth=.1):
    if architecture not in ARCHITECTURES:
        raise ValueError("Unsupported architecture: " + architecture)
    options = {"stochastic_depth_prob": stochastic_depth} if architecture.startswith("convnext") else {}
    model = getattr(models, architecture)(weights=None, **options)
    if architecture == "resnet18":
        model.fc = nn.Linear(model.fc.in_features, 10)
    elif architecture == "densenet121":
        model.classifier = nn.Linear(model.classifier.in_features, 10)
    elif architecture == "efficientnet_b3":
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 10)
    else:
        model.classifier[2] = nn.Linear(model.classifier[2].in_features, 10)
    return model


def load_initialization(model, path, expected_sha256):
    """Local torchvision ImageNet backbone state; only output-head shape changes allowed.

    The caller remains responsible for source/dataset/license verification. Hash
    matching ensures file identity, and does not itself prove competition eligibility.
    """
    if sha256(path) != expected_sha256.lower():
        raise ValueError("Initialization SHA256 mismatch")
    state = torch.load(path, map_location="cpu", weights_only=True)
    if not isinstance(state, dict) or not all(isinstance(v, torch.Tensor) for v in state.values()):
        raise ValueError("Initialization must be a plain torchvision state_dict")
    own = model.state_dict()
    permitted = {"fc.weight", "fc.bias", "classifier.weight", "classifier.bias",
                 "classifier.1.weight", "classifier.1.bias", "classifier.2.weight", "classifier.2.bias"}
    omitted = []
    for name in list(state):
        if name in own and state[name].shape != own[name].shape:
            if name not in permitted:
                raise ValueError("Non-head shape mismatch: " + name)
            omitted.append(name)
            del state[name]
    missing, unexpected = model.load_state_dict(state, strict=False)
    if set(missing) != set(omitted) or unexpected:
        raise ValueError("Incomplete/unexpected initialization tensors")
    return dict(sha256=expected_sha256.lower(), replaced_head_tensors=omitted)


def parameter_groups(model, architecture, learning_rate, weight_decay, stage_decay=1., exclude_norm_bias=False):
    """ConvNeXt stage decay is explicit; all trainable parameters occur once."""
    if not 0 < stage_decay <= 1 or learning_rate <= 0 or weight_decay < 0:
        raise ValueError("Invalid optimizer parameters")
    if stage_decay != 1 and not architecture.startswith("convnext"):
        raise ValueError("Stage decay is implemented for ConvNeXt only")
    groups, seen = {}, set()
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if id(parameter) in seen:
            raise ValueError("Duplicate parameter")
        seen.add(id(parameter))
        depth = 0
        if stage_decay != 1 and name.startswith("features."):
            depth = {0: 5, 1: 4, 2: 3, 3: 3, 4: 2, 5: 2, 6: 1, 7: 1}[int(name.split(".")[1])]
        no_decay = exclude_norm_bias and (parameter.ndim <= 1 or name.endswith(".bias"))
        key = (depth, 0. if no_decay else weight_decay)
        groups.setdefault(key, []).append(parameter)
    if not seen:
        raise ValueError("No trainable parameters")
    return [dict(params=parameters, lr=learning_rate * stage_decay**depth, weight_decay=decay)
            for (depth, decay), parameters in groups.items()]


class ModelEMA:
    def __init__(self, model, decay=.999):
        if not 0 < decay < 1:
            raise ValueError("EMA decay must be between 0 and 1")
        self.model = deepcopy(model).eval().requires_grad_(False)
        self.decay, self.updates = decay, 0

    @torch.no_grad()
    def update(self, model):
        source = model.state_dict()
        for name, value in self.model.state_dict().items():
            if value.is_floating_point():
                value.lerp_(source[name].detach(), 1 - self.decay)
            else:
                value.copy_(source[name])
        self.updates += 1
