"""Evaluate stored probabilities on labelled studies, without fitting parameters."""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from .common import parse_classes, sha256, write_json
from .data import label_vector, read_manifest
from .metrics import cohort_masks, metrics, paired_patient_bootstrap
from .predict import COLUMNS


def align_predictions(path, studies):
    frame = pd.read_csv(path, dtype={"Subject_id": str, "Study_id": str}, keep_default_na=False, float_precision="round_trip")
    if frame.columns.tolist() != COLUMNS or frame.duplicated(["Study_id", "Predict_class"]).any():
        raise ValueError("Malformed long-form prediction CSV")
    expected = {(r.Subject_id, r.Study_id, c) for r in studies.itertuples() for c in range(1, 11)}
    observed = set(frame[["Subject_id", "Study_id", "Predict_class"]].itertuples(index=False, name=None))
    if len(frame) != len(expected) or observed != expected:
        raise ValueError("Prediction identifiers/class grid do not exactly match labelled manifest")
    if not frame.Gate.eq(.5).all():
        raise ValueError("This reference expects the declared fixed Gate=.5")
    p = frame.pivot(index="Study_id", columns="Predict_class", values="Probability").loc[studies.Study_id, range(1, 11)].to_numpy(float)
    if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError("Invalid prediction values")
    return p


def run(args):
    if args.output.exists():
        raise FileExistsError("Analysis output exists; use a distinct registered analysis")
    frame = read_manifest(args.manifest, labelled=True)
    studies = frame.drop_duplicates("Study_id").reset_index(drop=True)
    y = np.stack([label_vector(v) for v in studies.Predict_class])
    p = align_predictions(args.predictions, studies)
    baseline = align_predictions(args.baseline, studies) if args.baseline else None
    cohorts = {}
    for name, mask in cohort_masks(studies.Subject_id).items():
        if not mask.any():
            cohorts[name] = {"studies": 0, "patients": 0, "metrics": None}
            continue
        result = dict(studies=int(mask.sum()), patients=int(studies.Subject_id[mask].nunique()),
                      candidate=metrics(y[mask], p[mask], args.score_classes))
        if baseline is not None:
            result["baseline"] = metrics(y[mask], baseline[mask], args.score_classes)
            result["per_class_delta"] = {str(c):
                (result["candidate"]["per_class"][str(c)]["auc"] - result["baseline"]["per_class"][str(c)]["auc"]
                 if result["candidate"]["per_class"][str(c)]["auc"] is not None else None) for c in args.score_classes}
        result["bootstrap"] = paired_patient_bootstrap(y[mask], p[mask], baseline[mask] if baseline is not None else None,
                studies.Subject_id[mask], args.score_classes, args.bootstrap, args.seed)
        cohorts[name] = result
    write_json(args.output, dict(score_classes=args.score_classes, cohorts=cohorts,
               manifest_sha256=sha256(args.manifest), predictions_sha256=sha256(args.predictions),
               baseline_sha256=sha256(args.baseline) if args.baseline else None,
               warning="Repeated development-set use and checkpoint selection can bias these estimates; cohorts do not predict public leaderboard scores.",
               high_frequency_definition="number of observed labelled studies per patient in this manifest; not lifetime history",
               analysis_only=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--score-classes", type=parse_classes, required=True,
                        help="Explicitly use 1,2,...,9 or 1,2,...,10 as appropriate; no retroactive metric substitution")
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
