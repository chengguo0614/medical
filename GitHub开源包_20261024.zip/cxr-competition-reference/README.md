# 胸片分类实验与可复核评估参考

这个仓库整理了一次 Study 级胸片多标签分类参赛开发的经验：患者划分、训练与内部选轮、普通与 EMA 权重、固定多图融合、患者配对 bootstrap，以及模型从单独改善到集成失效的完整结果。

**它不是冠军方案，也不承诺某个线上分数。** 历史最高成绩 77.10 和后续替换方案 77.01 均为参赛者报告，公开仓库未独立核验平台回执。报告同时保留长训、大模型、四折和替换失败的结果。

## 仓库内容

- [`cxr_reference/`](cxr_reference/)：整理后的公开参考实现，包含数据准备、训练、预测和评估入口。
- [`docs/CODE_GUIDE.md`](docs/CODE_GUIDE.md)：输入约定、运行命令、固定融合和参考实现的适用边界。
- [`RESULTS.md`](RESULTS.md)：主要结果和结论。
- [`docs/EXPERIMENTS.md`](docs/EXPERIMENTS.md)：比较设计、负面结果和统计限制。
- [`docs/DATA_AND_REPRODUCIBILITY.md`](docs/DATA_AND_REPRODUCIBILITY.md)：数据权利、来源、可复现范围及披露。
- [`docs/MODEL_SOURCES.md`](docs/MODEL_SOURCES.md)：历史保留模型的公开初始化链接、已有哈希与许可核验边界。
- [`docs/rules_proposal/`](docs/rules_proposal/)：提交给主办方参考的完整守则建议稿及说明。
- [`tools/check_public_release.py`](tools/check_public_release.py)：公开目录的保守文件与敏感模式检查。

## 先看边界

本仓库只发布代码、示例配置和聚合结果。没有比赛图像、标签、患者或检查清单、逐例预测、提交 CSV、训练权重、聊天记录和远程连接材料。示例和测试仅使用合成记录。请自行取得合法数据使用权，并核对具体初始化权重的许可证、上游数据与 SHA-256。

参考代码为适合公开阅读而整理的实现，**不是原始训练及部署目录的逐字镜像**，不应将它运行所得结果标成对 77.10 的位级复现。它不包含历史 CUDA Graph 部署优化和原赛方数据解析器。使用者须按自己的数据映射并独立验证。初始化默认不联网下载；任何外部初始化都必须显式指定来源与哈希。

## 开始使用

建议使用 Python 3.12，在独立虚拟环境安装依赖；PyTorch 应按自己的 CPU/CUDA 环境选择安装方式。依赖及本次实际验证版本见 [`requirements.txt`](requirements.txt) 和代码指南。

```bash
python -m pip install -r requirements.txt
python -m cxr_reference.prepare_data --help
python -m cxr_reference.train --help
python -m cxr_reference.predict --help
python -m cxr_reference.evaluate --help
```

合成数据自检不需要比赛数据、预训练权重、GPU 或网络：

```bash
python -m cxr_reference.smoke
python tools/check_public_release.py
```

真实训练与预测的完整命令见代码指南。标签接口仅支持完全标注：列出的类为阳性，未列出的类为阴性；存在未知或不确定标签的数据不能直接使用。评估必须显式填写 `--score-classes`，例如 `1,2,3,4,5,6,7,8,9` 或十类集合，不能让默认值替你决定赛事口径。

## 怎样解读结果

历史报告保留原来的**十类 Macro-AUC**。后续答疑中的“第十类不计分”没有在本仓库中被当作已核验的后台实现，也没有据此悄悄重写历史数值。缓存图像与共享原图、内部选轮与外层评估、单模与固定融合、普通与 EMA、线下 AUC 与用户报告线上分数均分开记录。

主要经验是：增加训练轮次和模型容量没有自动带来提升；新配方在患者留出上改善，也可能无法改善现役融合。高频患者组值得观察，但它不能直接换算成线上分数。公开结果不支持对其他队伍的作弊指控。

完整五模型包尚未完成正式 100 图 T4 端到端验收。本仓库不声明其速度或最终合规已经获得赛事认证；参考实现也不提供验收证书。

## 许可与贡献

本仓库中由项目贡献者拥有权利的代码及文档采用 [MIT License](LICENSE)。该许可不覆盖比赛数据、上游权重、第三方库及第三方内容；详见 [NOTICE](NOTICE)。历史探索的保留与排除情况在数据及复现文档中披露，不将所有旧目录包装成一套合规最终模型。

欢迎提交可以复核的问题、最小示例与改进。请勿在 issue、PR 或附件中上传患者信息、赛方数据、未授权权重、测试集预测或凭据。这个项目用于研究与工程交流，未作临床验证，不能用于临床诊断。
